
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2020 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f0xx_hal.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc;

SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim14;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
#define cs_set()  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET)
#define cs_reset()  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET)
#define cs_strob()  cs_set();cs_reset()
uint32_t aTxBuffer[1]={0};

#define TAP 1
#define POT 2
#define TAP_PERIOD_FASTEST 320
#define TAP_PERIOD_SLOWEST 1999
#define POT_PERIOD_FASTEST 50
#define POT_PERIOD_CLK_FASTEST 50
#define PERCENT_SENSE 2

uint16_t timedelay=50;
uint16_t input_tap_pointer=0;
uint16_t timer_ticks[2];
uint16_t tap_period=0;
uint16_t tap_period_led=0;
uint16_t last_tap_period = 0;

uint16_t pot_period;
uint16_t pot_period_clk;
uint16_t pot_period_array[256]={109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,
		130,131,132,133,134,135,137,138,139,140,141,143,144,145,146,148,149,150,152,153,154,156,157,158,160,161,
		162,164,165,167,168,170,171,173,174,176,177,179,180,182,183,185,187,188,190,192,193,195,197,198,200,202,
		204,205,207,209,211,213,215,216,218,220,222,224,226,228,230,232,234,236,238,240,242,244,247,249,251,253,
		255,258,260,262,264,267,269,271,274,276,279,281,283,286,288,291,293,296,299,301,304,306,309,312,315,317,
		320,323,326,329,331,334,337,340,343,346,349,352,355,358,362,365,368,371,374,378,381,384,388,391,394,398,
		401,405,408,412,416,419,423,426,430,434,438,442,445,449,453,457,461,465,469,473,478,482,486,490,494,499,
		503,507,512,516,521,525,530,535,539,544,549,554,558,563,568,573,578,583,588,593,599,604,609,614,620,625,
		631,636,642,647,653,659,665,670,676,682,688,694,700,706,712,719,725,731,738,744,751,757,764,770,777,784,
		791,798,805,812,819,826,833,840,848,855,863,870,878,885,893,901,909,917,925,933,941,949,957,966,974,983,
		991,1000};

uint16_t overflow_count=0;
uint8_t source_of_delay = POT;

volatile uint16_t ADC_Data_Rate = 0;
volatile uint16_t ADC_Data_Ratio = 0;
uint16_t ratio;
volatile uint16_t prev_ratio;
uint16_t ratio_flag_changes;
double denominator = 1;
uint16_t sector_ratio_1 = 1; //�����
double sector_ratio_2 = (double)1/4; //���������
double sector_ratio_3 = (double)1/8; //�������
double sector_ratio_4 = (double)3/16; //������� � ������
double sector_ratio_5 = (double)1/3; //������
uint16_t rate;
volatile uint16_t prev_rate;

__STATIC_INLINE void DelayMicro (__IO uint32_t micros)
{
	micros *=(SystemCoreClock / 1000000) / 5;
	while (micros--);
}
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC_Init(void);
static void MX_SPI1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM14_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
void programming_SPI(void);
void ADC_get_result(void);
void Pot_uninstall_param(void);
void Ratio_uninstall_param(void);
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  *
  * @retval None
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC_Init();
  MX_SPI1_Init();
  MX_TIM2_Init();
  MX_TIM14_Init();
  /* USER CODE BEGIN 2 */


  	  HAL_TIM_Base_Start_IT(&htim14);  //������ ��� ����������
  	  HAL_TIM_Base_Start_IT(&htim2);  //������ ��� ��������
  	  //HAL_TIM_Base_Start_IT(&htim3);  //SPI
  	  //HAL_ADC_Start_IT(&hadc);
  	  HAL_TIM_IC_Start_IT(&htim2,TIM_CHANNEL_1);


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  	  while (1)
  	  {

  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */

  		ADC_get_result();
  		Ratio_uninstall_param();
  		Pot_uninstall_param();


  	  }
  /* USER CODE END 3 */

}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSI14State = RCC_HSI14_ON;
  RCC_OscInitStruct.HSI14CalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* ADC init function */
static void MX_ADC_Init(void)
{

  ADC_ChannelConfTypeDef sConfig;

    /**Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion) 
    */
  hadc.Instance = ADC1;
  hadc.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc.Init.Resolution = ADC_RESOLUTION_12B;
  hadc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc.Init.ScanConvMode = ADC_SCAN_DIRECTION_FORWARD;
  hadc.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc.Init.LowPowerAutoWait = DISABLE;
  hadc.Init.LowPowerAutoPowerOff = DISABLE;
  hadc.Init.ContinuousConvMode = DISABLE;
  hadc.Init.DiscontinuousConvMode = ENABLE;
  hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc.Init.DMAContinuousRequests = DISABLE;
  hadc.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  if (HAL_ADC_Init(&hadc) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure for the selected ADC regular channel to be converted. 
    */
  sConfig.Channel = ADC_CHANNEL_2;
  sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
  sConfig.SamplingTime = ADC_SAMPLETIME_7CYCLES_5;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure for the selected ADC regular channel to be converted. 
    */
  sConfig.Channel = ADC_CHANNEL_3;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* SPI1 init function */
static void MX_SPI1_Init(void)
{

  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_1LINE;
  hspi1.Init.DataSize = SPI_DATASIZE_10BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 7;
  hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM2 init function */
static void MX_TIM2_Init(void)
{

  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_IC_InitTypeDef sConfigIC;

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 41999;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 999;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV4;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_IC_Init(&htim2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM14 init function */
static void MX_TIM14_Init(void)
{

  htim14.Instance = TIM14;
  htim14.Init.Prescaler = 41999;
  htim14.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim14.Init.Period = 499;
  htim14.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim14.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim14) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);

  /*Configure GPIO pin : PB0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PA8 */
  GPIO_InitStruct.Pin = GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance == TIM2)
	{
		if(overflow_count<2) overflow_count++;
						  		else
						  		{
						  			overflow_count=0;
						  			input_tap_pointer=0;

						  		}
	}
}

void ADC_get_result(void)
{
		HAL_ADC_Start(&hadc);
		HAL_ADC_PollForConversion(&hadc, 100);
		ADC_Data_Rate = HAL_ADC_GetValue(&hadc);

		HAL_ADC_Start(&hadc);
		HAL_ADC_PollForConversion(&hadc, 100);
		ADC_Data_Ratio = HAL_ADC_GetValue(&hadc);

}

void Pot_uninstall_param(void)
{
	rate = ADC_Data_Rate * 255 / 4096;
	  		  		  if(source_of_delay == TAP)
	  		  		  {
	  		  			  if((last_tap_period != tap_period) || (ratio_flag_changes == 1 || ratio_flag_changes == 2))
	  		  			  {
	  		  				last_tap_period = tap_period;
	  		  				aTxBuffer[0] = (last_tap_period * 255/1000) * denominator;
	  		  				ratio_flag_changes = 0;
	  		  			    programming_SPI();
	  		  			  }
	  		  			  if(rate>prev_rate+PERCENT_SENSE) source_of_delay = POT;
	  		  			  if((prev_rate>PERCENT_SENSE)&&(rate<prev_rate-PERCENT_SENSE)) source_of_delay = POT;

	  		  		  } else
	  		  		  {


	  		  			  pot_period_clk = rate;
	  		  			  pot_period = pot_period_array[rate];// / 4.5 * 3;

	  		  			  if(rate>prev_rate+PERCENT_SENSE || ratio_flag_changes == 1)
	  		  			  {
	  		  				  __HAL_TIM_SET_AUTORELOAD(&htim14, pot_period);
	  		  				 aTxBuffer[0] = pot_period_clk * denominator;
	  		  				 ratio_flag_changes = 0;
	  		  				 programming_SPI();


	  		  				  if(__HAL_TIM_GET_COUNTER(&htim14) >= pot_period){
	  		  					  __HAL_TIM_SET_COUNTER(&htim14, __HAL_TIM_GET_COUNTER(&htim14) % pot_period);
	  		  				  }

	  		  			  }
	  		  			  if(((prev_rate>PERCENT_SENSE)&&(rate<prev_rate-PERCENT_SENSE)) || (ratio_flag_changes == 2))
	  		  			  {
	  		  				  __HAL_TIM_SET_AUTORELOAD(&htim14, pot_period);
	  		  				  aTxBuffer[0] = pot_period_clk * denominator;
	  		  				  ratio_flag_changes = 0;
	  		  				  programming_SPI();

	  		  				  if(__HAL_TIM_GET_COUNTER(&htim14) >= pot_period){
	  		  					  __HAL_TIM_SET_COUNTER(&htim14, __HAL_TIM_GET_COUNTER(&htim14) % pot_period);
	  		  				  }

	  		  			  }

	  				          prev_rate=rate;
	  				          HAL_Delay(100);
	  		  		  }

}

void Ratio_uninstall_param(void)
{
	ratio = ADC_Data_Ratio;
	if(ratio>prev_ratio+PERCENT_SENSE)
	{
		if(ratio < 820) {denominator = sector_ratio_1;}
		if(ratio < 1640 && ratio >= 820)  {denominator = sector_ratio_2;}
		if(ratio < 2460 && ratio >= 1640) {denominator = sector_ratio_3;}
		if(ratio < 3280 && ratio >= 2460) {denominator = sector_ratio_4;}
		if(ratio < 4100 && ratio >= 3280) {denominator = sector_ratio_5;}
		ratio_flag_changes = 1;
	}
	if((ratio>PERCENT_SENSE)&&(ratio<prev_ratio-PERCENT_SENSE))
	{
		if(ratio < 820) denominator = sector_ratio_1;
		if(ratio < 1640 && ratio >= 820)  {denominator = sector_ratio_2;}
		if(ratio < 2460 && ratio >= 1640) {denominator = sector_ratio_3;}
		if(ratio < 3280 && ratio >= 2460) {denominator = sector_ratio_4;}
		if(ratio < 4100 && ratio >= 3280) {denominator = sector_ratio_5;}
		ratio_flag_changes = 2;
	}

	prev_ratio = ratio;
	HAL_Delay(100);
}

void programming_SPI(void)
{
	cs_set ();
	DelayMicro(10);


	//aTxBuffer[0] = aTxBuffer[0] * denominator;

	HAL_SPI_Transmit (&hspi1, (uint8_t*)aTxBuffer, 1, 5000);
	cs_reset();
	DelayMicro(10);
}




/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  file: The file name as string.
  * @param  line: The line in file as a number.
  * @retval None
  */
void _Error_Handler(char *file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
